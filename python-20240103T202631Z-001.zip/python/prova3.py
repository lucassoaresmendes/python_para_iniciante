# Lendo o número de registros
num_registros = int(input())

# Criando um dicionário para armazenar os dados de cada área
area_dict = {}

# Loop para ler e processar cada registro
for i in range(num_registros):
    # Lendo os dados do registro
    area, especie, quantidade = input().split()
    quantidade = int(quantidade)
    
    # Verificando se a área já existe no dicionário
    if area in area_dict:
        # Se a área já existe, adiciona a quantidade da espécie no dicionário correspondente
        especie_dict = area_dict[area]
        if especie in especie_dict:
            especie_dict[especie] += quantidade
        else:
            especie_dict[especie] = quantidade
    else:
        # Se a área não existe, cria um novo dicionário para a área e adiciona a quantidade da espécie
        area_dict[area] = {especie: quantidade}

# Variáveis para armazenar o total de alienígenas em todo o planeta
total_geral = 0

# Loop para imprimir os dados de cada área
for area in ["Alfa", "Beta", "Gama", "Delta", "Epsilon", "Zeta", "Eta", "Teta"]:
    # Verificando se a área existe no dicionário
    if area in area_dict:
        # Se a área existe, calcula o total de alienígenas na área e adiciona ao total geral
        especie_dict = area_dict[area]
        total_area = 0
        for quantidade in especie_dict.values():
            total_area += quantidade
        total_geral += total_area
        
        # Imprime o nome da área e o total de alienígenas na área
        print(area + " " + str(total_area))
    else:
        # Se a área não existe, imprime apenas o nome da área com total zero
        print(area + " 0")

# Imprime o total geral de alienígenas no planeta
print("Total " + str(total_geral))
