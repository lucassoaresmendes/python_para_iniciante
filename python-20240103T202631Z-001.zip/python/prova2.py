linhaColuna = 10
matriz = []
soma_aliens = 0
soma_terra = 0
poder_aliens = 0
poder_terra = 0

for i in range(linhaColuna):
	valor = list(map(int,input().split()))
	for elem in valor:
		if elem == 1:
			soma_aliens += 1
		elif elem == 2:
			soma_terra += 1

capacidade_aliens = int(input())
capacidade_terra = int(input())

poder_aliens = (soma_aliens * capacidade_aliens)
poder_terra = (soma_terra * capacidade_terra)

print(soma_aliens)
print(soma_terra)
print(poder_aliens)
print(poder_terra)

if poder_aliens > poder_terra:
	print("Aliens")
elif poder_aliens < poder_terra:
	print("Terra")
elif poder_aliens == poder_terra:
	print("Empate")
