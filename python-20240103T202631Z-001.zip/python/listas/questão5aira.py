f = list(map(float,input().split()))
d = list(map(float,input().split()))
w = 0

for elemento in range(len(f):
	trabalho += f[elemento]*d[elemento]
