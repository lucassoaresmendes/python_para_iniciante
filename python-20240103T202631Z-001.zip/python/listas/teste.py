def separarEmGrupos(grupoIdade,grupoC,grupoD):
    if ( len(grupoIdade) > 0 ):
        media = 0
        for cri in grupoIdade:
            media += cri["peso"]

        media = media/len(grupoIdade)

        print(media)
    
        for cri in grupoIdade:
            if ( cri["peso"] <= media ):
                grupoD.append(cri["nome"])
            else:
                grupoC.append(cri["nome"])
    else:
        print(0)

def principal():
    a = []
    b = []
    c = []
    d = []

    q = int(input())
    for i in range(q):

        n,i,p = input().split()
        i = int(i)
        p = float(p)

        cri = {}
        cri["nome"] = n
        cri["idade"] = i
        cri["peso"] = p

        if ( i >= 2 and i <= 4 ):
            a.append(cri)
        elif ( i >= 5 and i <= 7 ):
            b.append(cri)
        elif ( i >= 8 and i <= 10 ):
            c.append(cri)
        else:
            d.append(cri)

    grupoC = []
    grupoD = []

    separarEmGrupos(a,grupoC,grupoD)
    separarEmGrupos(b,grupoC,grupoD)
    separarEmGrupos(c,grupoC,grupoD)
    separarEmGrupos(d,grupoC,grupoD)

    for cri in grupoC:
        print(cri,end=" ")
    
    print()
    
    print(len(grupoD))

principal()
