"""
joao = 2,5% ao mes
pedro = 0.5% ao mes

joao = pedro


"""
valor_joao = int(input())
valor_pedro = int(input())

contador_mes = 0

while valor_joao < valor_pedro:
	
	valor_joao = (valor_joao*0.025) + valor_joao
	valor_pedro = (valor_pedro*0.005) + valor_pedro
	contador_mes += 1
		
print(contador_mes)

