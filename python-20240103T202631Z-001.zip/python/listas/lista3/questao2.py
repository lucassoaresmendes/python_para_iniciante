n1 = int(input())
n2 = int(input())
n3 = int(input())
n4 = int(input())
n5 = int(input())


if n1 < n2 and n1 < n3 and n1 < n4 and n1 < n5:
	if n2 > n1 and n2 < n3 and n2 < n4 and n2 < n5:
		if n3 > n1 and n3 > n2 and n3 < n4 and n3 < n5:
			if n4 > n1 and n4 > n2 and n4 > n3 and n4 < n5:
				if n5 > n1 and n5 > n2 and n5 > n3 and n5 > n4:
					print("1")
else:
	print("0")
			 
