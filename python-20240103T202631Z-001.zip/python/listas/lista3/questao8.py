temp = ""
contador = 0
letra = "x"
dia1 = 0
dia2 = 0
dia3 = 0
dia4 = 0
dia5 = 0
dia6 = 0
dia7 = 0

while contador < 7:
	temp = int(input())
	contador += 1
	if contador == 1:
		dia1 = (letra*temp)
	if contador == 2:
		dia2 = (letra*temp)
	if contador == 3:
		dia3 = (letra*temp)
	if contador == 4:
		dia4 = (letra*temp)
	if contador == 5:
		dia5 = (letra*temp)
	if contador == 6:
		dia6 = (letra*temp)
	if contador == 7:
		dia7 = (letra*temp)
print("D:",dia1)
print("S:",dia2)
print("T:",dia3)
print("Q:",dia4)
print("Q:",dia5)
print("S:",dia6)
print("S:",dia7)
		
	
