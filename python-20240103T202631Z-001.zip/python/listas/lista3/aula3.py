i = 0
while i < 10:
	if i < 9:
		print("Acorda")
	else:
		print("Hoje tem campeonato")
	i += 1
print("Pedrinho")
