numero = input()

posicao1 = numero[0:5]
posicao6 = numero[5]
posicao7 = numero[6]
posicao8 = numero[7]
posicao9 = numero[8]


print(str.format(posicao1 + posicao9 + posicao8 + posicao7 + posicao6))
