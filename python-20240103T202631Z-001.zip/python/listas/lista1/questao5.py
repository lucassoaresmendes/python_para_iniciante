from math import ceil

alturaCentimetro = int(input())

alturaMetro = int(input())

alturaDegrau = alturaMetro * 100

quantDegrau = ceil(alturaDegrau / alturaCentimetro)

print(quantDegrau)

