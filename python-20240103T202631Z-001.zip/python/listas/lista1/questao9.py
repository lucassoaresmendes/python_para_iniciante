valor = float(input())

notas50 = int(valor//50)
quantNota = valor % 50

notas10 = int(quantNota//10)
quantNota = quantNota % 10

notas5 = int(quantNota//5)
quantNota = quantNota % 5

notas1 = int(quantNota)

print(notas50)
print(notas10)
print(notas5)
print(notas1)
