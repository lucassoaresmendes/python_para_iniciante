preco = float(input())

valorVista = preco - (preco*(10/100))

valorSemJuro = (preco/5)

valorComJuro = (preco + preco*(0.2))/10


print(valorVista)
print(valorSemJuro)
print(valorComJuro)
