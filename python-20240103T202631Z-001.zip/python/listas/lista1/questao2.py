valor = int(input())

mult1 = valor * 1
mult2 = valor * 2
mult3 = valor * 3
mult4 = valor * 4
mult5 = valor * 5
mult6 = valor * 6
mult7 = valor * 7
mult8 = valor * 8
mult9 = valor * 9
mult10 = valor * 10

print(valor,"x 1 = ",mult1)
print(valor,"x 2 = ",mult2)
print(valor,"x 3 = ",mult3)
print(valor,"x 4 = ",mult4)
print(valor,"x 5 = ",mult5)
print(valor,"x 6 = ",mult6)
print(valor,"x 7 = ",mult7)
print(valor,"x 8 = ",mult8)
print(valor,"x 9 = ",mult9)
print(valor,"x 10 = ",mult10)
