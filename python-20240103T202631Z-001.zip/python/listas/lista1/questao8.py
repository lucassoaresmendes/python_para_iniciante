quantDinheiro = float(input())

canhao = int(quantDinheiro // 10000)
resto = quantDinheiro % 10000

polvora = int(resto // 2000)
resto = resto % 2000

espada = int(resto // 1500)

print(canhao)
print(polvora)
print(espada)
