avaliacao1 = float(input())

avaliacao2 = float(input())

avaliacao3 = float(input())

peso1 = float(input())           
              
peso2 = float(input())          

peso3 = float(input())           


result1 = avaliacao1 * peso1

result2 = avaliacao2 * peso2

result3 = avaliacao3 * peso3

soma = (peso1+peso2+peso3)

media = (result1+result2+result3)/soma

print(media)
