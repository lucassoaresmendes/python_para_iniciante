numero = int(input())

hora = int(numero // 3600000)
resto = numero % 3600000

minuto = int(resto // 60000)
resto = resto % 60000

segundo = float(resto / 1000)

print(hora, " : ",minuto," : ",segundo)
