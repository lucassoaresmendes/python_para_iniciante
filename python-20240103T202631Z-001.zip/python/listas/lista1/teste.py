av1= float(input())

av2= float(input())

av3= float(input())

p1= float(input())

p2= float(input())

p3= float(input())

nota1=av1*p1
nota2=av2*p2
nota3=av3*p3

somatoriapeso=p1+p2+p3
media=(nota1+nota2+nota3)/somatoriapeso

print(media)
