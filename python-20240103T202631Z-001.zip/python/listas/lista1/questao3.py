pes = float(input())

polegada = 12 * pes

jarda = 1/3 * pes

milha = 1/1760 * jarda

print(polegada)
print(jarda)
print(milha)
