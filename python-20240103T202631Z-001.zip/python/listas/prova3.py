valor_carro = float(input())

lucro = float(input())

imposto = float(input())

x = valor_carro* imposto

y = valor_carro*lucro

valor_final = x+y+valor_carro

print(y)

print(x)

print(valor_final)
