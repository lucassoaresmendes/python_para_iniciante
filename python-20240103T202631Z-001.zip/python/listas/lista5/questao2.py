n = list(map(int,input().split()))

somatorio = 0
for elemento in n:
	if elemento >= 0:
		somatorio += elemento

print(somatorio)
		
