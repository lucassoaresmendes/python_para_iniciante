'''
Sintaxe comando for

for variavel_auxiliar in nome_lista:
'''

for elemento in range(100,0,-10):
	print(elemento)
