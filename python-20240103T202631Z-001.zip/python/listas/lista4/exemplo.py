def alterar(x,y):
	print("Valores recebidos: ", x,y)
	x += 1
	y += 1
	print("Valores alterados: ", x,y)

def principal():
	a, b = 1, 2
	alterar(a,b)
	print("Valores finais: ", a,b)

principal()
