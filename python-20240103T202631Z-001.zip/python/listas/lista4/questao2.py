def operacaoDeposito(saldo,valor):
	novo_saldo = saldo + valor
	return novo_saldo

def  operacaoSaque(saldo,valor):
	if valor <= saldo:
		novo_saldo = saldo - valor
		return novo_saldo
	else:
		return "erro"


def controleOperacao(operacao,saldo,valor):
	if operacao == "D" or operacao == "1":
		resposta = operacaoDeposito(saldo,valor)
	elif operacao == "S" or operacao == "2":
		resposta = operacaoSaque(saldo,valor)
	else:
		resposta = "erro"
	return resposta
	
def principal():		
	x = float(input())
	y = float(input())
	op = input()
	print(controleOperacao(op,y,x))

principal()

