def potencia(u,r):
	pot = (u**2)/r
	return pot

def med(som, n):
	media = som / n
	return media

def principal():
	n = int(input())
	contador = 0
	som = 0
	while contador < n:
		contador +=1
		tensao, resistencia = map(float, input().split())
		som += potencia(tensao,resistencia)
		
		
	print(med(som,n))

principal()
	
	
