'''
Sintaxe para adicionar elementos na lista

nome_lista.append(novo_valor)
'''

numero = []
for contagem in range(5):
	escalar = int(input())
	numero.append(escalar)

print(escalar,numero)




