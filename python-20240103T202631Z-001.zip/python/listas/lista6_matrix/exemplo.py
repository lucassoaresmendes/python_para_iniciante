def principal():
	L, C = 4, 5
	for indice_sublista in range(L):
		for indice_elemento in range(C):
			print(indice_sublista, indice_elemento)

principal()
