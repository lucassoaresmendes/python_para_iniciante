cor1 = input()
cor2 = input()


if cor1 == "azul" and cor2 == "amarelo" or cor1 == "amarelo" and cor2 == "azul":
	print("verde")
elif cor1 == "azul" and cor2 == "vermelho" or cor1 == "vermelho" and cor2 == "azul":
	print("violeta")
elif cor1 == "vermelho" and cor2 == "amarelo" or cor1 == "amarelo" and cor2 == "vermelho":
	print("laranja")
elif cor1 == "azul" and cor2 == "azul":
	print("azul")
elif cor1 == "amarelo" and cor2 == "amarelo":
	print("amarelo")
elif cor1 == "vermelho" and cor2 == "vermelho":
	print("vermelho")
