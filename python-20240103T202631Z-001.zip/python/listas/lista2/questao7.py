nota_populacao = float(input())

estilo = input()

if estilo == "TERROR" or estilo == "GUERRA":
	nota_critico = nota_populacao * 0.9

elif estilo == "ACAO" or estilo == "FICCAO":
	nota_critico = nota_populacao * 0.8

elif estilo == "DRAMA" or estilo == "TRAGEDIA":
	nota_critico = nota_populacao * 1.2

elif estilo == "ROMANCE" or estilo == "SUSPENSE":
	nota_critico = nota_populacao

print(nota_critico)


