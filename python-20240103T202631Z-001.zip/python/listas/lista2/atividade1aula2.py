altura=float(input())
peso=float(input())

if altura<1.20:
	if peso<60:
		print("A")
	elif 60>= peso<=90:
		print("D")
	elif 
