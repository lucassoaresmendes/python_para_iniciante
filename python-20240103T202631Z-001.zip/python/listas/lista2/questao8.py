from math import *

numero = input()

posicao1 = numero[0]
posicao2 = numero[1]
posicao3 = numero[2]
posicao4 = numero[3]
posicao5 = numero[4]

posicao1 = int(posicao1)
posicao2 = int(posicao2)
posicao3 = int(posicao3)
posicao4 = int(posicao4)
posicao5 = int(posicao5)

contador2 = 0
contador3 = 0
contador_2_3 = 0


#Quando é divisivel por 2
# outro modo de fazer: if posicao1 % 2 == 0:
	
if (posicao1 / 2 == 0) or (posicao1 / 2 == 1) or (posicao1 / 2 == 2) or (posicao1 / 2 == 3)or (posicao1 / 2 == 4):
	contador2 += 1

if (posicao2 / 2 == 0) or (posicao2 / 2 == 1) or (posicao2 / 2 == 2) or (posicao2 / 2 == 3) or (posicao2 / 2 == 4):
	contador2 += 1

if (posicao3 / 2 == 0) or (posicao3 / 2 == 1) or (posicao3 / 2 == 2) or (posicao3 / 2 == 3) or (posicao3 / 2 == 4):
	contador2 += 1

if (posicao4 / 2 == 0) or (posicao4 / 2 == 1) or (posicao4 / 2 == 2) or (posicao4 / 2 == 3) or (posicao4 / 2 == 4):
	contador2 += 1

if (posicao5 / 2 == 0) or (posicao5 / 2 == 1) or (posicao5 / 2 == 2) or (posicao5 / 2 == 3) or (posicao5 / 2 == 4):
	contador2 += 1

#Quando é divisivel por 3
if (posicao1 / 3 == 0) or (posicao1 / 3 == 1) or (posicao1 / 3 == 2) or (posicao1 / 3 == 3) :
	contador3 += 1

if (posicao2 / 3 == 0) or (posicao2 / 3 == 1) or (posicao2 / 3 == 2) or (posicao2 / 3 == 3):
	contador3 += 1

if (posicao3 / 3 == 0) or (posicao3 / 3 == 1) or (posicao3 / 3 == 2) or (posicao3 / 3 == 3):
	contador3 += 1

if (posicao4 / 3 == 0) or (posicao4 / 3 == 1) or (posicao4 / 3 == 2) or (posicao4 / 3 == 3):
	contador3 += 1

if (posicao5 / 3 == 0) or (posicao5 / 3 == 1) or (posicao5 / 3 == 2) or (posicao5 / 3 == 3):
	contador3 += 1

#Quando for divisivel por 2 e 3
if ((posicao1 / 2 == 0)and(posicao1 / 3 == 0)) or ((posicao1 / 2 == 3)and(posicao1 / 3 == 2)):
	contador_2_3 += 1
if ((posicao2 / 2 == 0)and(posicao2 / 3 == 0)) or ((posicao2 / 2 == 3)and(posicao2 / 3 == 2)):
	contador_2_3 += 1
if ((posicao3 / 2 == 0)and(posicao3 / 3 == 0)) or ((posicao3 / 2 == 3)and(posicao3 / 3 == 2)):
	contador_2_3 += 1
if ((posicao4 / 2 == 0)and(posicao4 / 3 == 0)) or ((posicao4 / 2 == 3)and(posicao4 / 3 == 2)):
	contador_2_3 += 1
if ((posicao5 / 2 == 0)and(posicao5 / 3 == 0)) or ((posicao5 / 2 == 3)and(posicao5 / 3 == 2)):
	contador_2_3 += 1



print (contador2)
print (contador3)
print (contador_2_3)
