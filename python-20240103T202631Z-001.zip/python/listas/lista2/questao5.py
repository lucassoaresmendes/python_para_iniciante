from math import *

numero = input()

posicao2 = numero[1]
posicao5 = numero[4]

posicao2 = int(posicao2)
posicao5 = int(posicao5)

if (posicao2 + posicao5 == 7 or posicao2 + posicao5 == 8) and posicao2 * posicao5 == 12:
	print("Avancar")
else:
	print("Retroceder")
