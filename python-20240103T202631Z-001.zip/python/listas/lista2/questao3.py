letra_nota = input()

if letra_nota == "C":
	print("Do")
elif letra_nota == "D":
	print("Re")
elif letra_nota == "E":
	print("Mi")
elif letra_nota == "F":
	print("Fa")
elif letra_nota == "G":
	print("Sol")
elif letra_nota == "A":
	print("La")
elif letra_nota == "B":
	print("Si")

