from math import *

angulo = int(input())

valor_x = float(input())
valor_y = float(input())

calculo = 0

if angulo > 360:
	angulo = angulo % 360

if angulo > 0 and angulo < 90:
	calculo = valor_x + valor_y
elif angulo > 90 and angulo < 180:
	calculo = valor_x * valor_y
elif angulo > 180 and angulo < 270:
	calculo = valor_x / valor_y
elif angulo > 270 and angulo < 360:
	calculo = valor_x ** valor_y

print(calculo)
