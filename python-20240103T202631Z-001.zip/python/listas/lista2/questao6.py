from math import *

"""
molhada + quente = primavera = +10%
molhada + fria = inverno = -10%
seca + quente = verão = +20%
seca + fria = outono = exibir só

"""
estado_pedra1 = input()

estado_pedra2 = input()

temperatura = float(input())

if estado_pedra1 == "molhada" and estado_pedra2 == "quente" or estado_pedra1 == "quente" and estado_pedra2 == "molhada":
	print("Primavera")
	temperatura = temperatura + (temperatura*0.1)
	print(temperatura)

elif estado_pedra1 == "molhada" and estado_pedra2 == "fria" or estado_pedra1 == "fria" and estado_pedra2 == "molhada":
	print("Inverno")
	temperatura = temperatura - (temperatura*0.1)
	print(temperatura)

elif estado_pedra1 == "seca" and estado_pedra2 == "quente" or estado_pedra1 == "quente" and estado_pedra2 == "seca":
	print("Verão")
	temperatura = temperatura + (temperatura*0.2)
	print(temperatura)

elif estado_pedra1 == "seca" and estado_pedra2 == "fria" or estado_pedra1 == "fria" and estado_pedra2 == "seca":
	print("Outono")
	print(temperatura)
	
