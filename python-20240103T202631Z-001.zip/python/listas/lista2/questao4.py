from math import *

velocidade1 = float(input())
velocidade2 = float(input())
distancia = float (input())

tempo = distancia/(velocidade1+velocidade2)

if tempo > 0 and tempo <= 10:
	print("COLISAO")
else:
	print(tempo)
