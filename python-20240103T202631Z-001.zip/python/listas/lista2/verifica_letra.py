"""while True:
 texto = input()

 if texto.isupper():
  print("MAIUSCULO")
 elif texto.islower():
  print("MINUSCULO")
"""
letra = input()

if "A" <= letra <= "Z":
	print("MAIUSCULA")
elif "a" <= letra <= "z":
	print("MINUSCULA")
