salario = float(input())
tempo_empresa = int(input())

if tempo_empresa < 5:
    bonus_percentual = 0.10
else:
    bonus_percentual = 0.20

bonus = salario * bonus_percentual

print("O valor do bônus é %.2f" % bonus)