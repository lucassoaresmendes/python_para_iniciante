def pala(palavras,quant_caracteres):
	
	contadora = 0
	
	for posicao in range(len(palavras)):

		
		if len(palavras[posicao]) > quant_caracteres:
			contadora += 1

			
	return contadora

def principal():
	
	quant_pala = int(input())
	lista = []

	for elemento in range(quant_pala):
		palavras = input()
		lista.append(palavras)

	quant_caracteres = int(input())
	
 
	print(pala(lista,quant_caracteres))

principal()
'''



def comparacao(pala,lista):
	
	cont = 0
	for posicao in range(len(lista)):
		if lista[posicao] == pala:
			cont += 1

	return cont

def principal():

	quant_palavra = int(input())
	
	lista = []

	for posicao in range(quant_palavra):
		
		palavras = input()
		lista.append(palavras)

	pala = input()
	
	print(comparacao(pala,lista))

principal()
'''
