def teste(grupo,cont):
	turma = input()
	for cri in grupo:
		if (cri["codigoTurma"] == turma and cri["notaFinal"] >= 60):
			cont += 1

	return cont



def principal():
	quantidade = int(input())
	cont = 0
	for i in range(quantidade):

		nome,c,n = input().split()
		codigo = str(c)
		nota = float(n)

		cri = {}
		cri["nome"] = nome
		cri["codigoTurma"] = codigo
		cri["notaFinal"] = nota


	grupo = []

	print(teste(grupo,cont))

principal()
'''
7
Vega TurmaZ 80
Goku TurmaZ 50
Freeza TurmaG 30
trunks TurmaG 70
Kuririn TurmaG 40
Gohan TurmaC 90
Buma TurmaG 90
TurmaC
'''
