l , c = map(int,input().split())
matriz = []
soma = 0
menores = []


for i in range(l):
	lista = list(map(float,input().split()))
	matriz.append(lista)

for i in range(l):
	menor = matriz[i][1]
	for j in range (c):
		if matriz[i][j] < menor:
			menor = matriz[i][j]
	menores.append(menor)
	
menor = menores[1]

for i in range(len(menores)):
	if menor < menores[i]:
		menor = menores[i]

print(menor)

	
