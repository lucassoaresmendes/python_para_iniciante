t = 0
cont = 0
somatorio = 0

media_temp = 0
lista_temp = []

while cont < 7 and t >= 0:
	t = int(input())
	if t >= 0:
		lista_temp.append(t)
	cont += 1

for aux in range(len(lista_temp)):
	somatorio += lista_temp[aux]
	
media_temp = somatorio / len(lista_temp)

if media_temp >= 0 and media_temp <= 3:
	print(round(media_temp,2),"C")
	print("Alerta de Temperaturas Extremas – Tendência de forte frio nos próximos dias")
	
	for elemento in lista_temp:
		if elemento > media_temp:
			print(elemento)
			
else:
	print(round(media_temp,2),"C")
	
	for elemento in lista_temp:
		if elemento > media_temp:
			print(elemento)
