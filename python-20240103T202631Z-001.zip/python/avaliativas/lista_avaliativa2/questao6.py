def principal():
	contador = 0
	l_max = []
	l_min = []
	while contador < 7:
		x,y = map(int,input().split())
		l_min.append(x)
		l_max.append(y)
		contador = contador + 1
	print("Temperatura Minima da Semana: ",Temperatura_Minima(l_min),"C")
	print("Temperatura Maxima da Semana: ",Temperatura_Maxima(l_max),"C")
def Temperatura_Maxima(y):
	mai = y[0]
	for i in y:
		if i > mai :
			mai = i
	return mai
def Temperatura_Minima(x):
	men = x[0]
	for i in x:
		if i < men:
			men = i
	return men
principal()
