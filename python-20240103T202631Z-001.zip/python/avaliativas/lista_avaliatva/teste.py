def f_n(n):
	cnt_n=n
	acm_n=1
	while cnt_n>=1:
		acm_n=acm_n*cnt_n
		cnt_n-=1
	return acm_n

def f_p(p):
	cnt_p=p
	acm_p=1
	while cnt_p>=1:
		acm_p=acm_p*cnt_p
		cnt_p-=1
	return acm_p

def f_np(n,p):
	cnt_np=(n-p)
	acm_np=1
	while cnt_np>=1:
		acm_np=acm_np*cnt_np
		cnt_np-=1
	return acm_np

def combinacao(n,p):
	c=(f_n(n))/(f_p(p)*f_np(n,p))
	return c	
	
def principal():
	n,p=map(int,input().split())
	print(combinacao(n,p))
	
principal()
