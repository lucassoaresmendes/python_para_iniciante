vetor = list(map(float, input().split()))
num1 , num2 = map(int,input().split())
somatorio = 0
for elemento in range(num1,num2+1):
	somatorio = somatorio + vetor[elemento]
print (somatorio)
