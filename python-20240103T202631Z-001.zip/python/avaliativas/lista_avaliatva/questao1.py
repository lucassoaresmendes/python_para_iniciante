def combinacao(n,p):

	combinacao_simples = 0
	#fatorial n
	contadora_n = n
	acumuladora_n = 1
	while contadora_n >= 1:
		acumuladora_n = acumuladora_n * contadora_n
		contadora_n -= 1

	#fatorial p
	contadora_p = p
	acumuladora_p = 1
	while contadora_p >= 1:
		acumuladora_p = acumuladora_p * contadora_p
		contadora_p -= 1

	#fatorial n-p
	contadora_n_p = (n-p)
	acumuladora_n_p = 1
	while contadora_n_p >= 1:
		acumuladora_n_p = acumuladora_n_p * contadora_n_p
		contadora_n_p -= 1

	combinacao_simples = (acumuladora_n)/(acumuladora_p*acumuladora_n_p)

	return combinacao_simples	
	


def principal():
	n, p= map(int,input().split())
	print(combinacao(n,p))


principal()
