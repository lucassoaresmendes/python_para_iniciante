fita_dna = input()
peso_total= 0
aminoacido_a = (71.03711 + 18.01056)
aminoacido_c = (103.00919 + 18.01056)
aminoacido_g = (57.02146 + 18.01056)
aminoacido_t = (101.04768 + 18.01056)

contadora_a = 0
contadora_c = 0
contadora_g = 0
contadora_t = 0
for elemento in fita_dna:
	if elemento == "A":
		contadora_a += aminoacido_a
	elif elemento == "C":
		contadora_c += aminoacido_c
	elif elemento == "G":
		contadora_g += aminoacido_g
	elif elemento == "T":
		contadora_t += aminoacido_t
		
print(contadora_a + contadora_c + contadora_g + contadora_t)
