from math import *
forca_aplicada = list(map(float,input().split()))
deslocamento = list(map(float,input().split()))
trabalho = 0

for posicao in range(len(forca_aplicada)):
	trabalho += (forca_aplicada[posicao]*deslocamento[posicao])

if trabalho > 0:
	print("Trabalho motor")
	print(trabalho)
elif trabalho < 0:
	print("Trabalho resistente")
	print(abs(trabalho))
elif trabalho == 0:
	print("Trabalho nulo")
	print(trabalho)


