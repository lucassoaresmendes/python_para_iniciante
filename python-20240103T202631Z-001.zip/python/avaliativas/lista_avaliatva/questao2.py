def somatorio (x,y):
	cont_x = 0
	cont_y = 0
	expressao = 0
	for n in range(2,x+1):
		primo = True
		i = 2
		while i < n and primo:
			if n % i == 0:
				primo = False
			i += 1
		if primo:
			cont_x += n

	for n in range(2,y+1):
		primo = True
		i = 2
		while i < n and primo:
			if n % i == 0:
				primo = False
			i += 1
		if primo:
			cont_y += n

	expressao = (cont_x * cont_y)/(cont_x + cont_y)

	return expressao

def principal():
	x , y = map(int, input().split())
	print(somatorio(x,y))
	

principal()
